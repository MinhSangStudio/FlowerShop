﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FlowerShop.Models;

namespace FlowerShop.Controllers
{
    public class DefaultController : Controller
    {
        // GET: Default
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult AddtoCart(int MaSP)
        {
            //--- Lấy giỏ hàng từ Session ra ---//
            CartShop gh = Session["GioHang"] as CartShop;
            //--- Thêm sản phẩm vừa chọn mua vào giỏ hàng ---//
            gh.addItem(MaSP);
            //--- Cập nhật lại giỏ hàng vào trong Session---//
            Session["GioHang"] = gh;
            return View("~/Views/Default/Index.cshtml");
        }
    }
}