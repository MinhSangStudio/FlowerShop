﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FlowerShop.Models;

namespace FlowerShop.Controllers
{
    public class ProductController : Controller
    {
        // GET: Product
        FLOWERSHOPEntities obj = new FLOWERSHOPEntities();
        public ActionResult Index(int ID)
        {
            var listSP = obj.SanPhams.Where(n => n.MaNhom == ID).ToList();
            ViewBag.SanPhams = listSP;
            var tl = (from x in obj.NhomSPs where x.MaNhom == ID select x.TenNhom).First();
            ViewBag.Title = tl;
            return View();
        }
    }
}