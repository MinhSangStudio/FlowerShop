﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FlowerShop.Models;

namespace FlowerShop.Controllers
{
    public class ProductDetailController : Controller
    {

        FLOWERSHOPEntities obj = new FLOWERSHOPEntities();
        // GET: ProductDetail
       public ActionResult Index(int IDSP)
        {
            var SP = (from x in obj.SanPhams
                      where x.MaSP == IDSP
                      select x).First();
            ViewBag.SP = SP;
            var Hinh = (from c in obj.AnhSPs where c.MaSP == IDSP select c).ToList();
            ViewBag.Hinh = Hinh;
            ViewBag.Title = SP.TenSP;
            return View();
        }
    }
}