﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FlowerShop.Models
{
    public class CartShop
    {
        public int MaTV { get; set; }

        public string TaiKhoan { get; set; }
        public DateTime NgayDat { get; set; }
        public DateTime NgayGiao { get; set; }
        public string DiaChi { get; set; }
        ////-----
        ///----List ; ArrayList ; SortedList;..... <key> - <Value>
        public SortedList<int, ChiTietHD> SanPhamDC { get; set; }
        /// <summary>
        /// Default constructor
        /// </summary>
        public CartShop()
        {
            this.MaTV = 0; this.TaiKhoan = ""; this.NgayDat = DateTime.Now; this.NgayGiao = DateTime.Now.AddDays(2);
            this.DiaChi = "";
            this.SanPhamDC = new SortedList<int, ChiTietHD>();
        }
        /// <summary>
        /// Phương thức trả về true nếu không có sản phẩm nào mua trong hệ thống 
        /// </summary>
        /// <returns></returns>
        public bool IsEmpty()
        {
            return SanPhamDC.Keys.Count == 0;
        }
        /// <summary>
        /// phương thức thêm 1 sản phẩm đã chọn mua vào giỏ hàng có 2 tình huống 
        /// </summary>
        /// <param name="MaSP"></param>


        ///----Viết thêm 1 hàm dựa vào việc xóa cái cũ và thêm cái mới 

        public void updateOne(ChiTietHD x)
        {
            this.SanPhamDC.Remove(x.MaSP);
            this.SanPhamDC.Add(x.MaSP, x);
        }

        public void addItem(int MaSP)
        {
            if (SanPhamDC.Keys.Contains(MaSP))
            {
                ///--- LẤY SẢN PHẨM TỪ TRONG GIỎ HÀNG 
                ChiTietHD x = SanPhamDC.Values[SanPhamDC.IndexOfKey(MaSP)];
                ///--- TĂNG SỐ LƯỢNG LÊN 1 
                x.SoLuong++;
                ///---- NHÉT TRỞ LẠI GIỎ HÀNG SAU KHI ĐÃ CẬP NHẬT SỐ LƯỢNG 
                updateOne(x);
            }
            else
            {
                ///----- Tạo 1 object  chi tiết đơn hàng mới  
                ChiTietHD i = new ChiTietHD();
                ///---- Cập nhật thông tin hiện hành từ hệ thống cho đối tượng 
                i.MaSP = MaSP;
                i.SoLuong = 1;
                ///---- lấy giá bán ; lấy giảm giá  từ table SanPham
                SanPham z = CommonInfo.getProductByID(MaSP);
                i.GiaSP = z.GiaKM;
                ///---- bỏ vào danh sách các sản phẩm đã chọn mua trong giỏ hàng của mình 
                SanPhamDC.Add(MaSP, i);
            }

        }
        /// <summary>
        /// xóa 1 sản phẩm trong giỏ hàng 
        /// </summary>
        /// <param name="MaSP"></param>
        public void deleteItem(int MaSP)
        {
            if (SanPhamDC.Keys.Contains(MaSP))
            {
                SanPhamDC.Remove(MaSP);
            }

        }
        /// <summary>
        /// cho phép giảm số lượng hoặc xóa sản phẩm đã chọn hoặc danh sách giỏ hàng 
        /// </summary>
        /// <param name="MaSP"></param>
        public void decrease(int MaSP)
        {
            if (SanPhamDC.Keys.Contains(MaSP))
            {
                ChiTietHD x = SanPhamDC.Values[SanPhamDC.IndexOfKey(MaSP)];
                if (x.SoLuong > 1)
                {
                    x.SoLuong--;

                    updateOne(x);
                }
                else
                    deleteItem(MaSP);
            }

        }
        /// <summary>
        /// Tính trị giá tiền của 
        /// </summary>
        /// <param name="MaSP"></param>
        /// <returns></returns>
        public long moneyOfOneProduct(ChiTietHD x)
        {
            return (long)(x.GiaSP*x.SoLuong);

        }
        /// <summary>
        /// tính tổng thành viên cho toàn bộ giỏ hàng 
        /// </summary>
        /// <returns></returns>
        public long totalOfCartShop()
        {
            long kq = 0;

            foreach (ChiTietHD i in SanPhamDC.Values)
                kq += moneyOfOneProduct(i);
            return kq;
        }
    }
}