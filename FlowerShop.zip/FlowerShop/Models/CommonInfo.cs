﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace FlowerShop.Models
{
    public class CommonInfo
    {
        private FLOWERSHOPEntities db;
        public CommonInfo()
        {
            this.db = new FLOWERSHOPEntities();
        }
        public IEnumerable<NhomSP> NhomSPs
        {
            get
            {
                return this.db.NhomSPs;
            }
        }
        public IEnumerable<SanPham> SanPhams
        {
            get
            {
                return this.db.SanPhams;
            }
        }
        public IEnumerable<ChiTietHD> chiTietHDs
        {
            get
            {
                return this.db.ChiTietHDs;
            }
        }
        public IEnumerable<AnhSP> AnhSPs
        {
            get
            {
                return this.db.AnhSPs;
            }
        }
        public static List<ThanhVien> getThanhVien()
        {
            return new DbContext("name=FLOWERSHOPEntities").Set<ThanhVien>().ToList<ThanhVien>();
        }
        public static List<ThanhVien> getAccount()
        {
            List<ThanhVien> k = new List<ThanhVien>();
            DbContext cn = new DbContext("name=FLOWERSHOPEntities");
            //----Lấy dữ liệu.......
            k = cn.Set<ThanhVien>().ToList<ThanhVien>();
            return k;
        }
        public static ThanhVien getTaiKhoanById(string taiKhoan1)
        {
            return new DbContext("name=FLOWERSHOPEntities").Set<ThanhVien>().Find(taiKhoan1);
        }
        public static NhomSP getLoaiSPById(int MaNhom)
        {
            return new DbContext("name=FLOWERSHOPEntities").Set<NhomSP>().Find(MaNhom);
        }

        ///--- Hàm cho phép lấy ra danh sách sản phẩm theo ID cho CartShop---///
        public static SanPham getProductByID(int MaNhom)
        {
            return new DbContext("name=FLOWERSHOPEntities").Set<SanPham>().Find(MaNhom);
        }

        ///--- Hàm cho phép lấy ra "TÊN" của sản phẩm theo ID cho CartShop---///
        public static string getNameProductByID(int MaNhom)
        {
            return new DbContext("name=FLOWERSHOPEntities").Set<SanPham>().Find(MaNhom).TenSP;
        }

        ///--- Hàm cho phép lấy ra "ẢNH" của sản phẩm theo ID cho CartShop---///
        public static string getImageProductByID(int MaSP)
        {
            return new DbContext("name=FLOWERSHOPEntities").Set<AnhSP>().Find(MaSP).DuongDan;
        }
    }
}